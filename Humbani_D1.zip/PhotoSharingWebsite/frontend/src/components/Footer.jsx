function Footer(){
    <>
    <h1>this is the footer</h1>
    </>
}

export default Footer;